
<?php $__env->startSection('title', 'Attribute | '.config('app.name')); ?>
<?php $__env->startPush('style'); ?>
<link href="<?php echo e(asset('admin-assets/plugins/animate/animate.css')); ?>" rel="stylesheet" type="text/css" />
<link href="<?php echo e(asset('admin-assets/assets/css/scrollspyNav.css')); ?>" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('admin-assets/assets/css/forms/switches.css')); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div id="tableHover" class="col-lg-12 col-12 layout-spacing" style="padding: 15px 0;">
    
            <view-attribute />
        
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<?php echo app('Illuminate\Foundation\Vite')(['resources/js/app.js']); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layout.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\server82\htdocs\amyt\resources\views/pages/attribute/attribute.blade.php ENDPATH**/ ?>