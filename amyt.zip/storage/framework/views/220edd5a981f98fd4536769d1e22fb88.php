<?php $__env->startSection('title', 'Challan | '.env('APP_NAME')); ?>

<?php $__env->startSection('content'); ?>
<div id="tableHover" class="col-lg-12 col-12 layout-spacing" style="padding: 15px 0;">
    <div class="statbox">
        <div class="widget-header">
            <service from="3" title="Challan"/>
        </div>
    </div>
</div>
<!-- end modal -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<?php echo app('Illuminate\Foundation\Vite')(['resources/js/service.js']); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layout.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\server82\htdocs\amyt\resources\views/pages/challan/challan.blade.php ENDPATH**/ ?>