
<?php $__env->startSection('title', 'Edit Service | '.env('APP_NAME')); ?>
<?php $__env->startPush('style'); ?>
<style>
    .modal-dialog {
        max-width: 90%;
    }
</style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row layout-top-spacing" id="cancel-row">
        <div class="col-12">
            <form id="service-form" action="<?php echo e(route('service.update', $service->id)); ?>" method="POST"
                enctype="multipart/form-data" data-service='<?php echo json_encode($service, 15, 512) ?>'
                data-service-items='<?php echo json_encode($service->items, 15, 512) ?>'>
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <input type="hidden" name="service_id" value="<?php echo e($service->id); ?>">

                <!-- Hidden fields for form data -->
                <input type="hidden" id="dataItem" name="dataItem">
                <input type="hidden" id="total_amount" name="total_amount">
                <input type="hidden" id="payment_status" name="payment_status" value="<?php echo e($service->payment_status); ?>">
                <input type="hidden" id="discount" name="discount" value="<?php echo e($service->discount); ?>">
                <input type="hidden" id="discount_type" name="discount_type" value="<?php echo e($service->discount_type); ?>">
                <input type="hidden" id="status" name="status" value="<?php echo e($service->status); ?>">

                <!-- Service Details Card -->
                <div class="card mb-4">
                    <div class="card-header text-white">
                        <h5 class="mb-0">Edit Service Details</h5>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="basicFlatpickr">Service Date</label>
                                    <input id="basicFlatpickr" type="date"
                                        class="form-control" name="service_date" placeholder="Select Challan Date..">
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="invoice_no">Invoice No</label>
                                    <input type="text" class="form-control" id="invoice_no" name="invoice_no"
                                        value="<?php echo e($service->invoice_no); ?>">
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="customer_id">Select Customer</label>
                                    <select class="form-control" id="customer_id" name="customer_id" required>
                                        <option value=""></option>
                                        <?php if($service->customer_id): ?>
                                        <option value="<?php echo e($service->customer_id); ?>" selected><?php echo e($service->customer->name); ?></option>
                                        <?php endif; ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="document_link">Document (e.g., Invoice PDF)</label>
                                    <input type="file" class="form-control-file" id="document_link"
                                        name="document_link">
                                    <?php if($service->document_link): ?>
                                    <div class="mt-2">
                                        <a href="<?php echo e(asset($service->document_link)); ?>" target="_blank"
                                            class="btn btn-sm btn-info">View Current Document</a>
                                    </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="form-group">
                                    <label for="description">Description</label>
                                    <textarea class="form-control" placeholder="Description for the service order"
                                        rows="3" name="description"><?php echo e($service->description); ?></textarea>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Item List Card -->
                <div class="card mb-4">
                    <div class="card-header text-white d-flex justify-content-between align-items-center">
                        <h5 class="mb-0">Item List</h5>
                        <button type="button" class="btn btn-light" id="openModalBtn">
                            Add Item
                        </button>
                    </div>
                    <div class="card-body">
                        <div id="addedItemsSection" style="display: block;">
                            <div class="table-responsive">
                                <table class="table table-bordered table-striped">
                                    <thead>
                                        <tr>
                                            <th>Yarn Count</th>
                                            <th>Color</th>
                                            <th>Quantity</th>
                                            <th>Extra Quantity</th>
                                            <th>Gross Weight</th>
                                            <th>Net Weight</th>
                                            <th>Bobin</th>
                                            <th>Remark</th>
                                        </tr>
                                    </thead>
                                    <tbody id="addedItemsTableBody">
                                        <?php $__currentLoopData = $service->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($item->yarnCount->name); ?></td>
                                            <td><?php echo e($item->color->name); ?></td>
                                            <td><?php echo e($item->quantity); ?> <?php echo e($item->unitAttr->name); ?></td>
                                            <td><?php echo e($item->extra_quantity); ?></td>
                                            <td><?php echo e($item->gross_weight); ?> <?php echo e($item->weightAttr->name); ?></td>
                                            <td><?php echo e($item->net_weight); ?> <?php echo e($item->weightAttr->name); ?></td>
                                            <td><?php echo e($item->bobin); ?></td>
                                            <td><?php echo e($item->remark); ?></td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                    <tfoot>
                                        <tr class="font-weight-bold">
                                            <td colspan="2" class="text-right">Total:</td>
                                            <td id="totalQuantityCell"><?php echo e($service->items->sum('quantity')); ?> <?php echo e($service->items->first()->unitAttr->name ?? ''); ?></td>
                                            <td id="totalExtraQuantityCell"><?php echo e($service->items->sum('extra_quantity')); ?>

                                            </td>
                                            <td id="totalGrossWeightCell"><?php echo e($service->items->sum('gross_weight')); ?> <?php echo e($service->items->first()->weightAttr->name ?? ''); ?></td>
                                            <td id="totalNetWeightCell"><?php echo e($service->items->sum('net_weight')); ?> <?php echo e($service->items->first()->weightAttr->name ?? ''); ?></td>
                                            <td id="totalBobinCell"><?php echo e($service->items->sum('bobin')); ?></td>
                                            <td></td>
                                        </tr>
                                    </tfoot>
                                </table>
                            </div>
                        </div>
                        <div id="noItemsSection" style="display: none;">
                            <p class="text-muted">No items added yet.</p>
                        </div>
                    </div>
                </div>

                <!-- Submit Button -->
                <div class="text-center">
                    <button type="submit" class="btn btn-success btn-lg px-5">Update</button>
                    <a href="<?php echo e(url('admin/challan-list')); ?>" type="button" class="btn btn-dark btn-lg px-5">Cancel</a>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Add Item Modal -->
<div class="modal fade" id="addItemModal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-xl" role="document">
        <div class="modal-content">
            <div class="modal-header bg-default text-white">
                <h5 class="modal-title">Add/Edit Items</h5>
                <button type="button" class="close text-white" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Yarn Count</th>
                                <th>Color</th>
                                <th>Quantity</th>
                                <th>Extra Quantity</th>
                                <th>Gross Weight</th>
                                <th>Net Weight</th>
                                <th>Bobin</th>
                                <th>Remark</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody id="itemsTableBody">
                            <!-- Items will be added here dynamically -->
                        </tbody>
                    </table>
                </div>
                <button type="button" class="btn btn-info mt-2" id="addItemBtn">
                    Add Another Item
                </button>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary" id="saveItemsBtn">Done</button>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<script src="<?php echo e(asset('admin-assets/challan.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layout.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\server82\htdocs\amyt\resources\views/pages/challan/edit_challan.blade.php ENDPATH**/ ?>